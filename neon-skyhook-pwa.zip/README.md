# Neon Skyhook (PWA)

A one-thumb neon swing runner. Tap & hold to grapple, release to fling. Chain rings, avoid gates.

## Local test
Open `index.html` in a browser, or serve with any static server.

## GitHub Pages deploy (free)
1. Create a repo and add these files in the repo root.
2. Settings → Pages → Deploy from a branch → Branch: main (root).
3. Open the Pages URL on your phone, then Add to Home Screen / Install.
